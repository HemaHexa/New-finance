
import json

from kafka import KafkaProducer

from config.settings import (
    KAFKA_BOOTSTRAP_SERVERS,
    NEWS_TOPIC,
    LATEST_NEWS_TOPIC
)


class NewsKafkaPublisher:

    def __init__(self):
        self.producer = KafkaProducer(
            bootstrap_servers=KAFKA_BOOTSTRAP_SERVERS.split(","),
            acks="all",
            retries=5,
            max_in_flight_requests_per_connection=1,
            key_serializer=lambda key: key.encode("utf-8"),
            value_serializer=lambda value: json.dumps(
                value, ensure_ascii=False
            ).encode("utf-8")
        )

    def publish(self, article):
        article_id = article["article_id"]

        return self._publish_to_topic(
            NEWS_TOPIC,
            article_id,
            article,
            "NEW ARTICLE"
        )

    def publish_snapshot(self, symbol, article):
        return self._publish_to_topic(
            LATEST_NEWS_TOPIC,
            symbol,
            article,
            "LATEST NEWS SNAPSHOT"
        )

    def _publish_to_topic(self, topic, key, value, label):

        try:
            future = self.producer.send(
                topic,
                key=key,
                value=value
            )

            metadata = future.get(timeout=30)

            print(
                f"[{label}] {key} | "
                f"Topic: {metadata.topic} | "
                f"Partition: {metadata.partition} | "
                f"Offset: {metadata.offset}"
            )

            return True

        except Exception as error:
            print(f"[KAFKA ERROR] {topic}: {error}")
            return False

    def close(self):
        self.producer.flush()
        self.producer.close()